package ygw;

public class Circle {
	private static final double PI = 3.14;
	private double radius;

	/**
	 * @param radius
	 *            Բ�İ뾶
	 * @throws Exception
	 */
	public Circle(double radius) {
		if (radius > 0) {
			this.radius = radius;
		} else {
			try {
				throw new Exception("������Ϸ��İ뾶!");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public Circle() {

	}

	/**
	 * @param radius
	 *            Բ�İ뾶
	 * @return Բ�����
	 */
	public double getArea(double radius) {
		if (radius > 0) {
			return PI * radius * radius;
		} else {
			try {
				throw new Exception("������Ϸ��İ뾶!");
			} catch (Exception e) {
				e.printStackTrace();
				return 0;
			}
		}
	}
	/**
	 * @return Բ�����
	 */
	public double getArea() {
		return PI * radius * radius;

	}
	/**
	 * @param radius Բ�İ뾶
	 * @return Բ���ܳ�
	 */
	public double getPerimeter(double radius) {
		if (radius > 0) {
			return 2 * PI * radius;
		} else {
			try {
				throw new Exception("������Ϸ��İ뾶!");
			} catch (Exception e) {
				e.printStackTrace();
				return 0;
			}
		}
	}
	/**
	 * @return Բ���ܳ�
	 */
	public double getPerimeter() {
		if (radius > 0) {
			return 2 * PI * radius;
		} else {
			try {
				throw new Exception("������Ϸ��İ뾶!");
			} catch (Exception e) {
				e.printStackTrace();
				return 0;
			}
		}
	}
}
